# Repo Pulse

Repo Pulse is a responsive, single-page dashboard that turns public GitHub repository data into an elegant snapshot of project activity and health. It is built with plain HTML, CSS, and vanilla JavaScript, and can be hosted on GitHub Pages without a build step.

## Features

- Search by `owner/repo` or a public GitHub repository URL
- Repository summary with description, stars, forks, watchers, license, and last update
- Weekly commit activity chart covering the last year
- Open and closed issue counts with a donut chart
- Language breakdown chart
- Top five contributors with grayscale avatars and contribution counts
- Health score based on update recency, issue balance, contributor count, README, and license
- Dark and light themes, responsive glass-style layout, and accessible loading and error messages
- Recent repositories saved in browser `localStorage`
- Chart.js charts and Google Fonts loaded from CDNs

## Setup

1. Download or clone this project.
2. Keep `index.html`, `style.css`, and `script.js` in the same directory.
3. Open `index.html` in a browser, or serve the folder locally with any static web server.
4. Search for a public repository, for example `octocat/Hello-World`.

No dependencies need to be installed. The page loads Chart.js and the selected fonts from CDNs. GitHub’s unauthenticated API rate limits apply; if the public limit is reached, wait for it to reset before searching again.

## Screenshots

_Add screenshots here._

![Repo Pulse dashboard screenshot](screenshots/repo-pulse.png)

## Deploy to GitHub Pages

1. Create a GitHub repository and add `index.html`, `style.css`, `script.js`, `README.md`, and `LICENSE` to its root.
2. Push or commit the files to the repository’s default branch.
3. On GitHub, open the repository and go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the default branch and the `/ (root)` folder, then save.
6. Wait for the Pages deployment to finish. GitHub will show the site URL in the Pages settings.
7. Open the published URL and test a public repository search.

Because this is a static site, no build command or output directory is required.