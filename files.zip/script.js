"use strict";

// Repo Pulse uses only public GitHub REST API endpoints and stores recent
// repository names locally in this browser.
const API_ROOT = "https://api.github.com";
const RECENTS_KEY = "repo-pulse-recent-searches";
const MAX_RECENTS = 5;
const chartInstances = {};
const grayscalePalette = ["#ffffff", "#cfcfcf", "#a0a0a0", "#747474", "#505050", "#353535", "#202020", "#111111"];

const form = document.querySelector("#search-form");
const input = document.querySelector("#repo-input");
const loadingLine = document.querySelector("#loading-line");
const errorMessage = document.querySelector("#error-message");
const dashboard = document.querySelector("#dashboard");
const searchButton = document.querySelector("#search-button");
const themeToggle = document.querySelector("#theme-toggle");

document.addEventListener("DOMContentLoaded", () => {
  renderRecentSearches();
  restoreTheme();
});

form.addEventListener("submit", (event) => {
  event.preventDefault();
  loadRepository(input.value);
});

themeToggle.addEventListener("click", toggleTheme);

// Normalize a GitHub repository URL or owner/repo input to owner/repo.
function parseRepository(value) {
  let text = value.trim();

  if (!text) {
    throw new Error("Enter a repository as owner/repo or paste its GitHub URL.");
  }

  text = text.replace(/^https?:\/\//i, "").replace(/^www\./i, "");
  if (text.toLowerCase().startsWith("github.com/")) {
    text = text.slice("github.com/".length);
  }

  text = text.split(/[?#]/)[0].replace(/\.git$/i, "").replace(/\/+$/, "");
  const parts = text.split("/").filter(Boolean);

  if (parts.length !== 2 || !parts[0] || !parts[1]) {
    throw new Error("That doesn’t look like a repository. Try owner/repo or a GitHub repository URL.");
  }

  return `${parts[0]}/${parts[1]}`;
}

// Fetch JSON and translate common GitHub responses into clear messages.
async function fetchGitHub(path) {
  const response = await fetch(`${API_ROOT}${path}`, {
    headers: { Accept: "application/vnd.github+json" }
  });

  if (response.status === 404) {
    throw new Error("Repository not found. Check the owner and repository name, and make sure it’s public.");
  }

  if (response.status === 403 || response.status === 429) {
    const remaining = response.headers.get("X-RateLimit-Remaining");
    const reset = response.headers.get("X-RateLimit-Reset");
    if (remaining === "0" || response.status === 429) {
      const resetTime = reset ? new Date(Number(reset) * 1000).toLocaleTimeString() : "a little while";
      throw new Error(`GitHub’s public API rate limit has been reached. Please try again after ${resetTime}.`);
    }
    throw new Error("GitHub temporarily declined this request. Please try again shortly.");
  }

  if (!response.ok) {
    throw new Error(`GitHub returned an error (${response.status}). Please try again later.`);
  }

  return response.json();
}

async function loadRepository(value) {
  let fullName;
  try {
    fullName = parseRepository(value);
  } catch (error) {
    showError(error.message);
    return;
  }

  setLoading(true);
  hideError();

  try {
    const encodedName = fullName.split("/").map(encodeURIComponent).join("/");
    const repoPath = `/repos/${encodedName}`;

    // Requests are independent; fetching them together makes the dashboard faster.
    const [repo, activityResult, languagesResult, contributorsResult, readmeResult, openResult, closedResult] =
      await Promise.all([
        fetchGitHub(repoPath),
        fetchOptional(`${repoPath}/stats/commit_activity`),
        fetchGitHub(`${repoPath}/languages`),
        fetchOptional(`${repoPath}/contributors?per_page=100`),
        fetchOptional(`${repoPath}/readme`),
        fetchGitHub(`/search/issues?q=${encodeURIComponent(`repo:${fullName} is:issue state:open`)}&per_page=1`),
        fetchGitHub(`/search/issues?q=${encodeURIComponent(`repo:${fullName} is:issue state:closed`)}&per_page=1`)
      ]);

    displayRepository({
      repo,
      activity: Array.isArray(activityResult) ? activityResult : [],
      languages: languagesResult || {},
      contributors: Array.isArray(contributorsResult) ? contributorsResult : [],
      hasReadme: Boolean(readmeResult),
      openIssues: openResult.total_count || 0,
      closedIssues: closedResult.total_count || 0
    });

    saveRecent(fullName);
    renderRecentSearches();
    dashboard.hidden = false;
    dashboard.scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (error) {
    showError(error.message || "Something went wrong while fetching repository data.");
  } finally {
    setLoading(false);
  }
}

// Some GitHub statistics endpoints may return 202 while their data is being
// calculated, or 404 when no data is available. Those sections degrade gracefully.
async function fetchOptional(path) {
  try {
    return await fetchGitHub(path);
  } catch (error) {
    if (error.message.includes("rate limit")) {
      throw error;
    }
    return null;
  }
}

function setLoading(isLoading) {
  loadingLine.hidden = !isLoading;
  searchButton.disabled = isLoading;
  searchButton.innerHTML = isLoading ? "Reading…" : 'Explore <span aria-hidden="true">↗</span>';
}

function showError(message) {
  errorMessage.textContent = message;
  errorMessage.hidden = false;
}

function hideError() {
  errorMessage.hidden = true;
  errorMessage.textContent = "";
}

function displayRepository(data) {
  const { repo, activity, languages, contributors, hasReadme, openIssues, closedIssues } = data;
  document.querySelector("#repo-name").textContent = repo.full_name;
  document.querySelector("#repo-description").textContent = repo.description || "No description has been added to this repository.";
  document.querySelector("#repo-link").href = repo.html_url;
  document.querySelector("#repo-license").textContent = repo.license?.spdx_id || repo.license?.name || "Not specified";
  document.querySelector("#repo-updated").textContent = formatDate(repo.updated_at);

  animateCount(document.querySelector('[data-count="stars"]'), repo.stargazers_count || 0);
  animateCount(document.querySelector('[data-count="forks"]'), repo.forks_count || 0);
  // subscribers_count reflects users watching the repository; watchers_count is
  // retained by GitHub as a stars-compatible field.
  animateCount(document.querySelector('[data-count="watchers"]'), repo.subscribers_count || 0);

  renderActivityChart(activity);
  renderIssuesChart(openIssues, closedIssues);
  renderLanguagesChart(languages);
  renderContributors(contributors);

  const scoreData = calculateHealth({
    updatedAt: repo.updated_at,
    openIssues,
    closedIssues,
    contributorCount: contributors.length,
    hasReadme,
    hasLicense: Boolean(repo.license)
  });
  renderHealth(scoreData);
}

function formatDate(value) {
  if (!value) return "Unknown";
  return new Intl.DateTimeFormat(undefined, { year: "numeric", month: "short", day: "numeric" })
    .format(new Date(value));
}

function animateCount(element, value) {
  const target = Number(value) || 0;
  const duration = 850;
  const start = performance.now();

  function tick(now) {
    const progress = Math.min((now - start) / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    element.textContent = Math.round(target * eased).toLocaleString();
    if (progress < 1) requestAnimationFrame(tick);
  }

  requestAnimationFrame(tick);
}

// Health score: freshness (30), issue balance (20), contributors (20),
// README (15), and license (15). The explanation reports the actual components.
function calculateHealth({ updatedAt, openIssues, closedIssues, contributorCount, hasReadme, hasLicense }) {
  const daysSinceUpdate = updatedAt
    ? Math.max(0, (Date.now() - new Date(updatedAt).getTime()) / 86400000)
    : Infinity;

  let freshness = 0;
  if (daysSinceUpdate <= 7) freshness = 30;
  else if (daysSinceUpdate <= 30) freshness = 24;
  else if (daysSinceUpdate <= 90) freshness = 16;
  else if (daysSinceUpdate <= 180) freshness = 8;

  const issueTotal = openIssues + closedIssues;
  const issueBalance = issueTotal === 0 ? 20 : Math.round((closedIssues / issueTotal) * 20);
  const community = Math.min(20, contributorCount * 2);
  const readme = hasReadme ? 15 : 0;
  const license = hasLicense ? 15 : 0;
  const total = freshness + issueBalance + community + readme + license;

  return {
    total,
    explanation: `Freshness ${freshness}/30 · issue balance ${issueBalance}/20 · contributors ${community}/20 (${contributorCount} returned) · README ${readme}/15 · license ${license}/15.`
  };
}

function renderHealth({ total, explanation }) {
  const gauge = document.querySelector("#health-gauge");
  const scoreElement = document.querySelector("#health-score");
  gauge.style.setProperty("--score-angle", `${total * 3.6}deg`);
  gauge.setAttribute("aria-label", `Health score: ${total} out of 100`);
  document.querySelector("#health-explanation").textContent = explanation;
  animateCount(scoreElement, total);
}

function getChartColors() {
  const styles = getComputedStyle(document.body);
  return {
    text: styles.getPropertyValue("--text").trim(),
    muted: styles.getPropertyValue("--muted").trim(),
    grid: styles.getPropertyValue("--chart-grid").trim(),
    line: styles.getPropertyValue("--chart-line").trim()
  };
}

function destroyChart(name) {
  if (chartInstances[name]) {
    chartInstances[name].destroy();
    delete chartInstances[name];
  }
}

function renderActivityChart(activity) {
  destroyChart("activity");
  const canvas = document.querySelector("#activity-chart");
  const note = document.querySelector("#activity-note");

  if (!activity.length) {
    note.textContent = "Commit activity is not available yet. GitHub may still be calculating these statistics.";
    return;
  }

  note.textContent = "";
  const colors = getChartColors();
  const labels = activity.map((week) => {
    const date = new Date(Number(week.week) * 1000);
    return date.toLocaleDateString(undefined, { month: "short", day: "numeric" });
  });

  chartInstances.activity = new Chart(canvas, {
    type: "line",
    data: {
      labels,
      datasets: [{
        data: activity.map((week) => week.total || 0),
        borderColor: colors.line,
        backgroundColor: "rgba(255,255,255,0.08)",
        fill: true,
        tension: 0.35,
        pointRadius: 0,
        pointHoverRadius: 4,
        pointHoverBackgroundColor: colors.line,
        borderWidth: 2
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: {
          ticks: { color: colors.muted, maxTicksLimit: 6, maxRotation: 0 },
          grid: { display: false },
          border: { display: false }
        },
        y: {
          beginAtZero: true,
          ticks: { color: colors.muted, precision: 0 },
          grid: { color: colors.grid },
          border: { display: false }
        }
      }
    }
  });
}

function renderIssuesChart(openCount, closedCount) {
  destroyChart("issues");
  const total = openCount + closedCount;
  document.querySelector("#open-issues").textContent = openCount.toLocaleString();
  document.querySelector("#closed-issues").textContent = closedCount.toLocaleString();
  document.querySelector("#issue-total").textContent = total.toLocaleString();

  const colors = getChartColors();
  chartInstances.issues = new Chart(document.querySelector("#issues-chart"), {
    type: "doughnut",
    data: {
      labels: ["Open", "Closed"],
      datasets: [{
        data: total ? [openCount, closedCount] : [0, 1],
        backgroundColor: document.body.classList.contains("light") ? ["#111", "#aaa"] : ["#fff", "#666"],
        borderColor: "transparent",
        hoverOffset: 4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: "76%",
      plugins: {
        legend: { display: false },
        tooltip: { titleColor: colors.text, bodyColor: colors.text }
      }
    }
  });

  document.querySelector("#issues-note").textContent =
    "Counts exclude pull requests and come from GitHub’s issue search.";
}

function renderLanguagesChart(languageData) {
  destroyChart("languages");
  const entries = Object.entries(languageData).sort((a, b) => b[1] - a[1]);
  const note = document.querySelector("#languages-note");

  if (!entries.length) {
    note.textContent = "No language data is available for this repository.";
    return;
  }

  const top = entries.slice(0, 7);
  const remainder = entries.slice(7).reduce((sum, entry) => sum + entry[1], 0);
  if (remainder > 0) top.push(["Other", remainder]);

  const colors = getChartColors();
  chartInstances.languages = new Chart(document.querySelector("#languages-chart"), {
    type: "doughnut",
    data: {
      labels: top.map(([name]) => name),
      datasets: [{
        data: top.map(([, bytes]) => bytes),
        backgroundColor: top.map((_, index) => grayscalePalette[index % grayscalePalette.length]),
        borderColor: "transparent",
        hoverOffset: 4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: "64%",
      plugins: {
        legend: {
          position: "right",
          labels: {
            color: colors.text,
            boxWidth: 9,
            boxHeight: 9,
            padding: 13,
            font: { family: "Cormorant Garamond", size: 15 }
          }
        }
      }
    }
  });
  note.textContent = "Relative byte counts reported by GitHub.";
}

function renderContributors(contributors) {
  const list = document.querySelector("#contributor-list");
  const note = document.querySelector("#contributors-note");
  list.replaceChildren();

  const visible = contributors.filter((person) => person && person.login).slice(0, 5);
  if (!visible.length) {
    note.textContent = "Contributor data is not available for this repository.";
    return;
  }

  visible.forEach((person) => {
    const row = document.createElement("li");
    row.className = "contributor-row";

    const avatar = document.createElement("img");
    avatar.className = "contributor-avatar";
    avatar.src = person.avatar_url;
    avatar.alt = "";
    avatar.loading = "lazy";

    const link = document.createElement("a");
    link.className = "contributor-name";
    link.href = person.html_url;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.textContent = person.login;

    const count = document.createElement("strong");
    count.className = "contributor-count";
    count.textContent = (person.contributions || 0).toLocaleString();

    const unit = document.createElement("span");
    unit.textContent = " commits";
    count.append(unit);

    row.append(avatar, link, count);
    list.append(row);
  });

  note.textContent = "Ranked by contributions returned by GitHub (up to 100 contributors checked).";
}

function getRecents() {
  try {
    const parsed = JSON.parse(localStorage.getItem(RECENTS_KEY) || "[]");
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveRecent(fullName) {
  const recents = [fullName, ...getRecents().filter((item) => item !== fullName)].slice(0, MAX_RECENTS);
  try {
    localStorage.setItem(RECENTS_KEY, JSON.stringify(recents));
  } catch {
    // The app still works if browser storage is disabled or full.
  }
}

function renderRecentSearches() {
  const recents = getRecents();
  const wrapper = document.querySelector("#recent-searches");
  const chips = document.querySelector("#recent-chips");
  chips.replaceChildren();
  wrapper.hidden = recents.length === 0;

  recents.forEach((name) => {
    const chip = document.createElement("button");
    chip.className = "recent-chip";
    chip.type = "button";
    chip.textContent = name;
    chip.addEventListener("click", () => {
      input.value = name;
      loadRepository(name);
    });
    chips.append(chip);
  });
}

function restoreTheme() {
  let isLight = false;
  try {
    isLight = localStorage.getItem("repo-pulse-theme") === "light";
  } catch {
    // Fall back to the default dark theme.
  }
  applyTheme(isLight);
}

function toggleTheme() {
  applyTheme(!document.body.classList.contains("light"));
  try {
    localStorage.setItem("repo-pulse-theme", document.body.classList.contains("light") ? "light" : "dark");
  } catch {
    // Theme switching remains available for the current page view.
  }

  // Recreate charts so their labels and surfaces match the selected palette.
  if (!dashboard.hidden) {
    const repoName = document.querySelector("#repo-name").textContent;
    if (repoName && repoName !== "—") {
      // Chart instances are re-rendered with the current palette using retained data.
      Object.values(chartInstances).forEach((chart) => chart.update());
    }
  }
}

function applyTheme(isLight) {
  document.body.classList.toggle("light", isLight);
  document.querySelector("#theme-label").textContent = isLight ? "Dark mode" : "Light mode";
  themeToggle.setAttribute("aria-label", isLight ? "Switch to dark mode" : "Switch to light mode");
}